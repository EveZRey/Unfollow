//* **GitHub:** [Eve Z Rey](https://github.com/evezrey)
//* **Instagram:** [@cehort.gl](https://instagram.com/cehort.gl)

const { chromium } = require("playwright");
const fs = require("fs");

const ARCHIVO_SESION = "auth.json";

const rawFollowers = fs.readFileSync("followers.json");
const rawFollowing = fs.readFileSync("following.json");

const jsonFollowers = JSON.parse(rawFollowers);
const jsonFollowing = JSON.parse(rawFollowing);

const seguidores = jsonFollowers
  .map((perfil) => {
    const valor = perfil.string_list_data?.[0]?.value;
    const titulo = perfil.title;
    return valor || titulo;
  })
  .filter(Boolean);

const seguidos = jsonFollowing.relationships_following
  .map((perfil) => {
    const valor = perfil.string_list_data?.[0]?.value;
    const titulo = perfil.title;
    return valor || titulo;
  })
  .filter(Boolean);

const setSeguidores = new Set(seguidores);
const noMeSiguen = seguidos.filter((usuario) => !setSeguidores.has(usuario));

console.log(
  `📊 Sigues a ${seguidos.length} personas. ${seguidores.length} te siguen.`,
);
console.log(`🔥 Hay ${noMeSiguen.length} cuentas que NO te siguen de vuelta.`);

const pausarAleatoriamente = (minMs, maxMs) => {
  const tiempo = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
  console.log(`⏱️ Pausa anti-spam: Esperando ${tiempo / 1000} segundos...`);
  return new Promise((resolve) => setTimeout(resolve, tiempo));
};

(async () => {
  const browser = await chromium.launch({ headless: false });
  let context;
  let page;

  if (fs.existsSync(ARCHIVO_SESION)) {
    console.log("✅ Archivo auth.json detectado. Cargando tu sesión...");
    context = await browser.newContext({ storageState: ARCHIVO_SESION });
    page = await context.newPage();
  } else {
    console.log(
      "⚠️ No se encontró auth.json. Preparando inicio de sesión manual...",
    );
    context = await browser.newContext();
    page = await context.newPage();

    await page.goto("https://www.instagram.com/");
    console.log(
      "⏳ Tienes 60 segundos para iniciar sesión manualmente en el navegador...",
    );

    await page.waitForTimeout(60000);
    await context.storageState({ path: ARCHIVO_SESION });
    console.log(`💾 Sesión guardada exitosamente en ${ARCHIVO_SESION}`);
  }

  for (const usuario of noMeSiguen) {
    try {
      console.log(`\nNavegando al perfil de: ${usuario}...`);
      await page.goto(`https://www.instagram.com/${usuario}/`);

      const botonSiguiendo = page
        .getByText("Siguiendo", { exact: true })
        .first();
      await botonSiguiendo.waitFor({ state: "visible", timeout: 8000 });
      await botonSiguiendo.click();

      await page.waitForTimeout(2000);

      const botonConfirmar = page
        .getByText("Dejar de seguir", { exact: true })
        .first();
      await botonConfirmar.waitFor({ state: "visible", timeout: 5000 });
      await botonConfirmar.click();

      console.log(`✅ Dejaste de seguir a ${usuario}.`);

      await pausarAleatoriamente(24000, 42000);
    } catch (error) {
      console.error(
        `❌ No se pudo procesar a ${usuario}. Error: ${error.message}`,
      );
      await pausarAleatoriamente(15000, 30000);
    }
  }

  console.log("🎉 Limpieza masiva finalizada.");
  await browser.close();
})();
