@echo off
color 0A
title Bot de Limpieza de Instagram
echo ===================================================
echo Preparando el Bot de Limpieza...
echo ===================================================


node -v >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo [ERROR CRITICO] Node.js no esta instalado en esta computadora.
    echo El bot necesita Node.js para funcionar.
    echo Por favor, descargalo e instalalo desde: https://nodejs.org/
    echo.
    pause
    exit
)

echo [1/3] Instalando el motor del bot...
call npm install playwright --no-fund --no-audit --silent

echo [2/3] Descargando el navegador oculto...
call npx playwright install chromium

echo [3/3] Iniciando la magia...
echo ===================================================
node unfollow.js

echo.
echo ===================================================
echo El proceso ha terminado o fue interrumpido.
pause